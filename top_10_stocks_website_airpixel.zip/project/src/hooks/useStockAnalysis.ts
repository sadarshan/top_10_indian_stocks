import { useMemo } from 'react';
import { getStockAnalysis } from '../utils/stockAnalysis';

export function useStockAnalysis(
  symbol: string,
  sector: string,
  price: number,
  marketCap: number
) {
  return useMemo(() => 
    getStockAnalysis(symbol, sector, price, marketCap),
    [symbol, sector, price, marketCap]
  );
}