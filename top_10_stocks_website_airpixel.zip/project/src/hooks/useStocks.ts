import { useState, useEffect } from 'react';
import { fetchStockData } from '../utils/gemini';
import { stocksCache } from '../utils/cache';
import { defaultStocks } from '../data/indianStocks';
import type { StockData } from '../types/stock';

export function useStocks() {
  const [stocks, setStocks] = useState<StockData[]>(() => {
    // Initialize from cache or default stocks
    return stocksCache.get() || defaultStocks;
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(() => {
    return stocksCache.isExpired() ? null : new Date();
  });

  useEffect(() => {
    let mounted = true;

    async function updateStocks() {
      if (!mounted) return;
      
      // Skip if cache is still valid
      if (!stocksCache.isExpired()) return;
      
      setLoading(true);
      setError(null);
      
      try {
        const data = await fetchStockData();
        
        if (!mounted) return;
        
        if (data) {
          setStocks(data);
          stocksCache.set(data);
          setLastUpdated(new Date());
        } else {
          setError('Unable to fetch latest stock data. Showing cached data.');
        }
      } catch (err) {
        if (!mounted) return;
        setError('Failed to fetch latest stock data. Showing cached data.');
        console.error(err);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    updateStocks();
    
    // Check for updates every hour
    const interval = setInterval(updateStocks, 60 * 60 * 1000);
    
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  return { 
    stocks, 
    loading, 
    error,
    lastUpdated 
  };
}