import React from 'react';
import Header from './components/Header';
import StockList from './components/StockList';
import AdBanner from './components/AdBanner';
import GoogleAdsScript from './components/GoogleAdsScript';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <GoogleAdsScript />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex gap-8">
          <AdBanner position="left" />
          <div className="flex-1">
            <StockList />
          </div>
          <AdBanner position="right" />
        </div>
      </main>

      <footer className="bg-blue-900 text-white py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">
            Disclaimer: This information is for educational purposes only and should not be considered as financial advice.
            Always do your own research and consult with a SEBI registered financial advisor before making investment decisions.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;