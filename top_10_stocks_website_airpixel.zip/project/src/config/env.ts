export const config = {
  geminiApiKey: import.meta.env.VITE_GEMINI_API_KEY as string
};