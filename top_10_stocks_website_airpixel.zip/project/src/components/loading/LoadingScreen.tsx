import React from 'react';
import { FinancialLoadingCard } from './FinancialLoadingCard';
import { LoadingStats } from './LoadingStats';

export function LoadingScreen() {
  return (
    <div className="space-y-6">
      <LoadingStats />
      <div className="grid gap-6 md:grid-cols-2">
        {Array.from({ length: 4 }).map((_, index) => (
          <FinancialLoadingCard key={index} />
        ))}
      </div>
    </div>
  );
}