import React from 'react';
import { IndianRupee, TrendingUp, Activity } from 'lucide-react';

export function LoadingStats() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
      {[
        { icon: IndianRupee, label: "Market Cap" },
        { icon: TrendingUp, label: "Daily Volume" },
        { icon: Activity, label: "Market Volatility" }
      ].map(({ icon: Icon, label }, index) => (
        <div key={index} className="bg-white rounded-lg shadow p-3 md:p-4 animate-pulse">
          <div className="flex items-center space-x-2 md:space-x-3">
            <Icon className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
            <div className="flex-1">
              <div className="h-2 md:h-3 bg-gray-200 rounded w-1/2"></div>
              <div className="h-3 md:h-4 bg-gray-300 rounded w-3/4 mt-1 md:mt-2"></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}