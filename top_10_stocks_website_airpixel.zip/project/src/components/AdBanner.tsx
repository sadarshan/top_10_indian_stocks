import React from 'react';

interface AdBannerProps {
  position: 'left' | 'right';
}

export default function AdBanner({ position }: AdBannerProps) {
  return (
    <div className="hidden lg:block w-64">
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-2305590157607767"
        data-ad-slot="auto"
        data-ad-format="vertical"
        data-full-width-responsive="false"
      />
    </div>
  );
}