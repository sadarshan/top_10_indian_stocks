import React from 'react';
import { Building2, PlusCircle, MinusCircle, ChevronDown, ChevronUp } from 'lucide-react';
import type { StockData } from '../types/stock';

export default function StockCard({ symbol, name, sector, pros, cons }: StockData) {
  const [isExpanded, setIsExpanded] = React.useState(false);

  return (
    <div className="bg-white rounded-lg shadow-md p-4 md:p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start gap-4 mb-4">
        <div className="bg-blue-100 rounded-lg p-2 md:p-3">
          <Building2 className="w-5 h-5 md:w-6 md:h-6 text-blue-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg md:text-xl font-bold text-gray-800">{symbol}</h3>
          <p className="text-sm md:text-base text-gray-600">{name}</p>
          <p className="text-xs md:text-sm text-gray-500">{sector}</p>
        </div>
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="md:hidden text-gray-500 p-2"
        >
          {isExpanded ? <ChevronUp /> : <ChevronDown />}
        </button>
      </div>
      
      <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${!isExpanded ? 'hidden md:grid' : ''}`}>
        <div>
          <h4 className="text-sm font-semibold text-green-700 flex items-center mb-2">
            <PlusCircle className="w-4 h-4 mr-1" />
            Pros
          </h4>
          <ul className="text-xs md:text-sm space-y-1">
            {pros.map((pro, index) => (
              <li key={index} className="text-gray-700">• {pro}</li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-red-700 flex items-center mb-2">
            <MinusCircle className="w-4 h-4 mr-1" />
            Cons
          </h4>
          <ul className="text-xs md:text-sm space-y-1">
            {cons.map((con, index) => (
              <li key={index} className="text-gray-700">• {con}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}