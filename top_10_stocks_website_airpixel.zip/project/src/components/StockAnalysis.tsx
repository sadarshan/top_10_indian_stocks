import React from 'react';
import { PlusCircle, MinusCircle } from 'lucide-react';

interface StockAnalysisProps {
  symbol: string;
  sector: string;
  price: number;
  marketCap: number;
}

export default function StockAnalysis({ symbol, sector, price, marketCap }: StockAnalysisProps) {
  const analysis = useStockAnalysis(symbol, sector, price, marketCap);
  
  return (
    <div className="mt-4 space-y-3">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h4 className="text-sm font-semibold text-green-700 flex items-center mb-2">
            <PlusCircle className="w-4 h-4 mr-1" />
            Pros
          </h4>
          <ul className="text-sm space-y-1">
            {analysis.pros.map((pro, index) => (
              <li key={index} className="text-gray-700">• {pro}</li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-red-700 flex items-center mb-2">
            <MinusCircle className="w-4 h-4 mr-1" />
            Cons
          </h4>
          <ul className="text-sm space-y-1">
            {analysis.cons.map((con, index) => (
              <li key={index} className="text-gray-700">• {con}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}