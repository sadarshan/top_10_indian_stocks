import React from 'react';
import StockCard from './StockCard';
import { LoadingScreen } from './loading/LoadingScreen';
import { useStocks } from '../hooks/useStocks';
import { AlertCircle, RefreshCw } from 'lucide-react';

export default function StockList() {
  const { stocks, loading, error, lastUpdated } = useStocks();

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <RefreshCw className={`w-4 h-4 text-blue-600 ${loading ? 'animate-spin' : ''}`} />
          {lastUpdated && (
            <span className="text-sm text-gray-600">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </span>
          )}
        </div>
        {error && (
          <div className="flex items-center text-amber-600 text-sm">
            <AlertCircle className="w-4 h-4 mr-1" />
            <span>{error}</span>
          </div>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {stocks.map((stock) => (
          <StockCard key={stock.symbol} {...stock} />
        ))}
      </div>
    </div>
  );
}