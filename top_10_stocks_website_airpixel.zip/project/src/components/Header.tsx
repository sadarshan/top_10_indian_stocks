import React from 'react';
import { TrendingUp, Menu, X } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="container mx-auto px-4 py-4 md:py-6">
        <div className="flex items-center justify-between md:justify-center">
          <div className="flex items-center">
            <TrendingUp className="w-6 h-6 md:w-8 md:h-8 mr-2 md:mr-3" />
            <div>
              <h1 className="text-xl md:text-3xl font-bold">Top 10 Indian Stocks</h1>
              <p className="text-xs md:text-base text-blue-100 mt-1 md:mt-2">
                Expert Analysis & Daily NSE/BSE Stock Recommendations
              </p>
            </div>
          </div>
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2"
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {isMenuOpen && (
          <nav className="mt-4 md:hidden">
            <ul className="space-y-2">
              <li>
                <a href="#stocks" className="block py-2 px-4 hover:bg-blue-700 rounded">
                  Stocks
                </a>
              </li>
              <li>
                <a href="#analysis" className="block py-2 px-4 hover:bg-blue-700 rounded">
                  Analysis
                </a>
              </li>
              <li>
                <a href="#about" className="block py-2 px-4 hover:bg-blue-700 rounded">
                  About
                </a>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  );
}