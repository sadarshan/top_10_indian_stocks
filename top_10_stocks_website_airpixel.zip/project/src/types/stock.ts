export interface StockData {
  symbol: string;
  name: string;
  sector: string;
  pros: string[];
  cons: string[];
}