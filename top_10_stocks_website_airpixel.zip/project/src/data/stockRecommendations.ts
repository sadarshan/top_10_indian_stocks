export const stockRecommendations = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 172.45,
    change: 2.3,
    reason: "Strong iPhone 15 sales and growing services revenue stream. AI integration plans show promise."
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corporation",
    price: 415.50,
    change: 1.8,
    reason: "Leading position in AI technology and cloud services through Azure. Strong enterprise demand."
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corporation",
    price: 875.20,
    change: 3.5,
    reason: "Dominant position in AI chips and continued strong demand for data center GPUs."
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 147.60,
    change: 1.2,
    reason: "AI advancements with Gemini and strong digital advertising recovery."
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    price: 178.25,
    change: 2.1,
    reason: "AWS growth and retail efficiency improvements driving margin expansion."
  },
  {
    symbol: "TSM",
    name: "Taiwan Semiconductor",
    price: 142.30,
    change: 1.5,
    reason: "Critical position in global chip manufacturing and AI chip production."
  },
  {
    symbol: "META",
    name: "Meta Platforms Inc.",
    price: 505.75,
    change: 2.8,
    reason: "Strong advertising recovery and successful cost optimization initiatives."
  },
  {
    symbol: "AMD",
    name: "Advanced Micro Devices",
    price: 185.90,
    change: 2.6,
    reason: "Gaining market share in data center CPUs and new AI chip offerings."
  },
  {
    symbol: "ASML",
    name: "ASML Holding",
    price: 968.45,
    change: 1.7,
    reason: "Monopoly in advanced semiconductor manufacturing equipment."
  },
  {
    symbol: "CRM",
    name: "Salesforce.com",
    price: 305.80,
    change: 1.9,
    reason: "AI integration boosting product offerings and strong enterprise software demand."
  }
];