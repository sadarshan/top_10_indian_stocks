import type { StockData } from '../types/stock';

export const defaultStocks: StockData[] = [
  {
    symbol: "RELIANCE",
    name: "Reliance Industries",
    sector: "Conglomerate",
    pros: [
      "Diversified business model",
      "Strong retail presence",
      "Leading telecom operator",
      "Green energy initiatives"
    ],
    cons: [
      "High capital expenditure",
      "Regulatory challenges",
      "Oil price sensitivity",
      "Complex corporate structure"
    ]
  },
  {
    symbol: "TCS",
    name: "Tata Consultancy Services",
    sector: "Information Technology",
    pros: [
      "Global IT services leader",
      "Strong client relationships",
      "High margins",
      "Consistent dividend payer"
    ],
    cons: [
      "Wage inflation pressure",
      "High attrition rates",
      "Global economic sensitivity",
      "Currency volatility risks"
    ]
  }
  // Adding more stocks would follow the same pattern
];