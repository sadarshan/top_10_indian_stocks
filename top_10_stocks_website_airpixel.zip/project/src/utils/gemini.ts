import { GoogleGenerativeAI } from '@google/generative-ai';
import type { StockData } from '../types/stock';
import { config } from '../config/env';

const genAI = new GoogleGenerativeAI(config.geminiApiKey);

const STOCK_PROMPT = `
Generate a JSON array of the top 10 Indian stocks to invest in today. For each stock, include:
- symbol: Stock symbol
- name: Company name
- sector: Business sector
- pros: Array of 4-5 key advantages/strengths
- cons: Array of 4-5 key risks/weaknesses

Only return valid JSON data. No additional text.
`;

function validateStockData(data: any[]): data is StockData[] {
  return Array.isArray(data) && 
    data.length === 10 &&
    data.every(stock => 
      typeof stock.symbol === 'string' &&
      typeof stock.name === 'string' &&
      typeof stock.sector === 'string' &&
      Array.isArray(stock.pros) &&
      Array.isArray(stock.cons)
    );
}

export async function fetchStockData(): Promise<StockData[] | null> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    const result = await model.generateContent(STOCK_PROMPT);
    const response = await result.response;
    const text = response.text();
    
    const cleanJson = text.replace(/```json\n?|```/g, '').trim();
    const parsedData = JSON.parse(cleanJson);
    
    if (!validateStockData(parsedData)) {
      console.error('Invalid data structure received from API');
      return null;
    }
    
    return parsedData;
  } catch (error) {
    console.error('Error fetching stock data:', error);
    return null;
  }
}