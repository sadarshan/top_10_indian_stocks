import type { StockData } from '../types/stock';

interface CacheItem<T> {
  data: T;
  timestamp: number;
}

class Cache<T> {
  private key: string;
  private ttl: number;

  constructor(key: string, ttlInMinutes: number) {
    this.key = key;
    this.ttl = ttlInMinutes * 60 * 1000; // Convert to milliseconds
  }

  set(data: T): void {
    const item: CacheItem<T> = {
      data,
      timestamp: Date.now(),
    };
    localStorage.setItem(this.key, JSON.stringify(item));
  }

  get(): T | null {
    const item = localStorage.getItem(this.key);
    if (!item) return null;

    const { data, timestamp }: CacheItem<T> = JSON.parse(item);
    const isExpired = Date.now() - timestamp > this.ttl;

    return isExpired ? null : data;
  }

  isExpired(): boolean {
    const item = localStorage.getItem(this.key);
    if (!item) return true;

    const { timestamp }: CacheItem<T> = JSON.parse(item);
    return Date.now() - timestamp > this.ttl;
  }
}

export const stocksCache = new Cache<StockData[]>('stocks', 60); // 60 minutes TTL