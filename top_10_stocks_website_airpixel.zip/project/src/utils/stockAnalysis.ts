interface StockAnalysis {
  pros: string[];
  cons: string[];
}

const sectorAnalysis: Record<string, { pros: string[], cons: string[] }> = {
  'Information Technology': {
    pros: [
      'High growth potential',
      'Strong global presence',
      'Recession-resistant revenue streams',
      'High profit margins'
    ],
    cons: [
      'Sensitive to global economic conditions',
      'High employee costs',
      'Intense competition',
      'Currency fluctuation risks'
    ]
  },
  'Banking': {
    pros: [
      'Essential sector for economy',
      'Stable dividend yields',
      'Benefits from rising interest rates',
      'Strong regulatory oversight'
    ],
    cons: [
      'Vulnerable to economic downturns',
      'NPA risks',
      'Interest rate sensitivity',
      'Regulatory compliance costs'
    ]
  },
  'Automotive': {
    pros: [
      'Growing domestic market',
      'Export opportunities',
      'EV transition potential',
      'Strong brand value'
    ],
    cons: [
      'Cyclical nature',
      'Raw material price volatility',
      'High capital requirements',
      'Emission regulation risks'
    ]
  },
  'Pharmaceuticals': {
    pros: [
      'Defensive sector',
      'R&D capabilities',
      'Export opportunities',
      'Growing healthcare demand'
    ],
    cons: [
      'Regulatory risks',
      'R&D costs',
      'Patent expiry risks',
      'Price control measures'
    ]
  },
  'Conglomerate': {
    pros: [
      'Diversified revenue streams',
      'Risk mitigation through diversification',
      'Strong market position',
      'Multiple growth avenues'
    ],
    cons: [
      'Complex business structure',
      'Management challenges',
      'Capital allocation risks',
      'Conglomerate discount'
    ]
  }
};

const defaultAnalysis = {
  pros: [
    'Established market presence',
    'Strong brand recognition',
    'Professional management',
    'Growth potential'
  ],
  cons: [
    'Market competition',
    'Economic sensitivity',
    'Regulatory risks',
    'Industry-specific challenges'
  ]
};

export function getStockAnalysis(
  symbol: string,
  sector: string,
  price: number,
  marketCap: number
): StockAnalysis {
  const baseAnalysis = sectorAnalysis[sector] || defaultAnalysis;
  
  // Add company-specific analysis based on market cap
  const marketCapAnalysis = {
    pros: marketCap > 100000 ? ['Strong market leadership', 'High liquidity'] : ['Growth potential', 'Acquisition target'],
    cons: marketCap > 100000 ? ['Limited growth potential', 'High base effect'] : ['Limited market influence', 'Lower liquidity']
  };

  return {
    pros: [...baseAnalysis.pros, ...marketCapAnalysis.pros],
    cons: [...baseAnalysis.cons, ...marketCapAnalysis.cons]
  };
}